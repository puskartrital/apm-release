{
	"sProcessing":   "Bitte warten...",
	"sLengthMenu":   "_MENU_ Eintr&auml;ge anzeigen",
	"sZeroRecords":  "Keine Eintr&auml;ge vorhanden.",
	"sInfo":         "_START_ bis _END_ von _TOTAL_ Eintr&auml;gen",
	"sInfoEmpty":    "0 bis 0 von 0 Eintr&auml;gen",
	"sInfoFiltered": "(gefiltert von _MAX_  Eintr&auml;gen)",
	"sInfoPostFix":  "",
	"sSearch":       "Suchen:",
	"sUrl":          "",
	"oPaginate": {
		"sFirst":    "Erster",
		"sPrevious": "Zur&uuml;ck",
		"sNext":     "N&auml;chster",
		"sLast":     "Letzter"
		}
}